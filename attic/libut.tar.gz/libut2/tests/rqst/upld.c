/*******************************************************************************
* upld.c                                                                       *
* A test program. Takes hostname, port, and filename as three args to the upld *
* shl command. Sends the raw file to the host/port.                            *
* Copyright Troy Hanson, 21 July 2005                                          *
*******************************************************************************/
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <string.h>
#include "libut/ut.h"

int upld_done_cb(char *name, void *data, int flags, UT_iob *rqst, UT_iob *resp) 
{

    UT_iob_free(rqst);

    if (flags & UTFD_IS_REQFAILURE) {
        UT_log(Error, "upld failed");
        return;
    }

    /* can assume REQSUCCESS since we did not have REQFALURE */
    if (flags & UTFD_IS_REQSUCCESS) UT_log(Info, "upld finished");

    if (resp) UT_log(Error,"unexpected non-NULL response buffer");
}

int file_to_iob(UT_iob **iob_head,char *filename) {
    struct stat stat_buf;
    char *text;
    int fd;

    UT_log(Debug, "reading file %s", filename);

    if ( (fd = open(filename, O_RDONLY)) == -1 ) {
        UT_log(Error,"Couldn't open file %s: %s", filename, strerror(errno));
        return 0;
    }

    if ( fstat(fd, &stat_buf) == -1) {
        close(fd);
        UT_log(Error,"Couldn't stat file %s: %s", filename, strerror(errno));
        return 0;
    }

    /* map the file into memory */
    text = (char*)mmap(0, stat_buf.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (text == MAP_FAILED) {
        close(fd);
        UT_log(Error,"Failed to mmap %s: %s", filename, strerror(errno));
        return 0;
    }

    UT_iob_append(iob_head, text, stat_buf.st_size);
    if ( munmap( text, stat_buf.st_size ) == -1 ) {
        UT_log(Error,"Failed to munmap %s: %s", filename, strerror(errno));
    }
    close(fd);
}

int upld_test_cmd(int argc, char *argv[] ) {
    int rc,port;
    UT_iob *sendiob=NULL;
    char *dst_ipport;

    if (argc != 3) {
        UT_shle("usage: upld <file> <host:port>\n");
        return SHL_ERROR;
    }

    if ( (dst_ipport = UT_net_resolve( argv[2])) == NULL ) {
        UT_shle("name resolution of %s failed\n", argv[2]);
        return SHL_ERROR;
    }

    file_to_iob(&sendiob,argv[1]);
    if (sendiob == NULL) {
        UT_shle("upld failed\n");
        return SHL_ERROR;
    }
    rc = UT_net_request("upld", upld_done_cb, NULL, sendiob, UT_CONNECT_TO_IPPORT,
            dst_ipport); 
    if (rc < 0) {
        UT_shle("request error");
        return SHL_ERROR;
    }
    return SHL_OK;
}

int dns_test_cmd(int argc, char *argv[] ) {
    char *s;

    if (argc != 2) {
        UT_shle("usage: dns host:port");
        return SHL_ERROR;
    }

    s = UT_net_resolve(argv[1]);
    UT_shlf("%s converts to %s\n", argv[1], (s ? s : "<invalid>"));
    return SHL_OK;
}

int main(int argc, char **argv) {
	UT_init(INIT_END);
    UT_shl_cmd_create("upld", "upload <file> to <host> <port>",upld_test_cmd,NULL);
    UT_shl_cmd_create("dns", "translate host:port to ip:port", dns_test_cmd, NULL);
	UT_event_loop();
}
