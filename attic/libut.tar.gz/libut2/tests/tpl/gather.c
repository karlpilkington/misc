#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include "libut/ut.h"

int gather_cb(int fd, UT_tpl *tplq, void *data) {
    if (!tplq) {
        UT_log(Info, "app received notice of tpl fd closure");
    }
    while (tplq) {
        UT_log(Info, "app received tpl of length %d",tplq->sz);
        tplq=tplq->next;
    }
}

int srvr_cb(int fd, char *name, int flags, int *count) {

    if (flags & UTFD_IS_NEWACCEPT) {
        UT_tpl_deq_reg(fd, name, gather_cb, NULL);  /* re-reg this fd for tpl */
        return 0;
    }
}

int main(int argc, char **argv) {
    UT_init(INIT_END);
    UT_net_listen("srvr", "*:2222", (UT_fd_cb*)srvr_cb, NULL);
    UT_event_loop();
}
