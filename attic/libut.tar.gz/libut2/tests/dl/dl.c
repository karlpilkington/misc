#include "libut/ut.h"

struct list_el {
    char c;
    struct list_el *prev, *next;
} *els = NULL;

int dladd_cmd(int argc, char *argv[]) {
    struct list_el *el;
    el = UT_malloc(sizeof(struct list_el));
    el->next = NULL;
    el->prev = NULL;
    el->c = (argc > 1) ? argv[1][0] : '?';
    DL_ADD(els,el);
    for(el=els; el; el=el->next) UT_shlf("%c ", el->c);
    UT_shlf("\n");
    if (els) for(el=els->prev; el; el=((el==els) ? NULL : el->prev)) 
        UT_shlf("%c ", el->c);
    UT_shlf("\n");
    return SHL_OK;
}

int dldel_cmd(int argc, char *argv[]) {
    int i,j;
    struct list_el *el;
    if (argc > 1) {
        if (sscanf(argv[1],"%d",&j) != 1) {
            UT_shle("non-numeric input");
            return SHL_ERROR;
        }
    }
    for(i=0, el=els; i<j; i++) el=el->next;
    DL_DEL(els,el);
    UT_free(el);
    for(el=els; el; el=el->next) UT_shlf("%c ", el->c);
    UT_shlf("\n");
    if (els) for(el=els->prev; el; el=((el==els) ? NULL : el->prev)) 
        UT_shlf("%c ", el->c);
    UT_shlf("\n");
    return SHL_OK;
}

int main(int argc, char **argv) {
	UT_init(INIT_END);
    UT_shl_cmd_create( "dladd", "add linked list item 'a'", dladd_cmd, NULL);
    UT_shl_cmd_create( "dldel", "delete linked list item #", dldel_cmd, NULL);
	UT_event_loop();
}
