#include <stdlib.h>
#include "libut/ut.h"

typedef struct example_t {
    int id;
    void *other_data;
    UT_hash_handle hh;
    struct example_t *next;
} example_t;

example_t *list = NULL;

int showh_cmd(int argc, char *argv[]) {
    example_t *ex;
    for(ex=list;ex;ex=ex->next) UT_shlf("%d ",ex->id);
    UT_shlf("\n");
    return SHL_OK;
}

int addh_cmd(int argc, char *argv[]) {
    example_t *ex, *tmp, *del;
    int i, num, replaced=0;

    if (argc > 1) {
        if (sscanf(argv[1], "%d", &num) != 1) {
            UT_shle("error: non-numeric argument");
            return SHL_ERROR;
        }
    } else num = (int)((10*1.0 * rand()) / (RAND_MAX+1.0));

    ex = (example_t*)UT_pmalloc("idpool", 1);
    ex->id = num;
    ex->next = NULL;

    HASH_FIND_INT(list, del, id, &ex->id);
    if (del) {
        replaced=1;
        HASH_DEL(list,del);
        UT_pfree("idpool",del);
    }
    HASH_ADD_INT(list, id, ex);
    UT_shlf("Stored %d in hash %s\n", num, (replaced ? "(dup)" : ""));
    showh_cmd(0,NULL);
    return SHL_OK;
}

int clearh_cmd(int argc, char *argv[]) {
    example_t *ex,*nxt,*tmp;
    for(ex=list;ex;ex=nxt) {
        nxt=ex->next;
        HASH_DEL(list,ex);
        UT_pfree("idpool",ex);
    }
    return SHL_OK;
}

int main() {
    UT_init(INIT_END);
    UT_shl_cmd_create("showh", "show the hash", showh_cmd, NULL);
    UT_shl_cmd_create("addh", "add <int> to hash", addh_cmd, NULL);
    UT_shl_cmd_create("clearh", "clear hash", clearh_cmd, NULL);
    UT_pcreate("idpool", sizeof(example_t));
    UT_event_loop();
}
