#include "libut/ut.h"

int main(int argc, char **argv) {
	UT_init(INIT_END);
	UT_event_loop();
}
