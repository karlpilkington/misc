#!/usr/bin/perl

# send_cmd.pl: sends each arg as a separate control port command. TDH 11Apr06.

use strict;
use warnings;
use IO::Socket::INET;

my $socket = IO::Socket::INET->new("localhost:4445") or die "can't connect: $!";
print $socket "$_\n" for (@ARGV);
shutdown($socket,1);

undef $/;
print <$socket>;
