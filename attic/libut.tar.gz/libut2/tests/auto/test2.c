#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include "libut/ut.h"

#define SPRAY_BUFLEN (1024*1024)  

/* This test sprays the alphabet repeatedly to the connector 
 * as a test of the buffered-write handling for recipients
 * that cannot read the data as fast as we can send it. 
 */

int spray_cb(int fd, char *name, int flags, int *count) {
    int i,rc,f;
    char buf[SPRAY_BUFLEN];

    for(i=0; i < SPRAY_BUFLEN; i++) buf[i] = (i % 26) + 'a';

    if (flags & UTFD_IS_NEWACCEPT) {
        UT_fd_write(fd, buf, SPRAY_BUFLEN);
        UT_fd_close(fd);
        return 0;
    }
    UT_log(Info,"fd readable"); /* not expected for this test */
}

int main(int argc, char **argv) {
    UT_init(INIT_END);
    UT_net_listen("spray", "*:2222", (UT_fd_cb*)spray_cb, NULL);
    UT_event_loop();
}
