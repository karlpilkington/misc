/*
Copyright (c) 2003-2006, Troy Hanson
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <string.h>
#include <stdlib.h>
#include "libut/ut_internal.h"

#define PCT_MAXLEN 5

/*******************************************************************************
* mem_shl.c                                                                    *
* Copyright (c) 2003-2006 Troy Hanson                                          *
*******************************************************************************/
extern UT_mem_global_type UT_mem_global;


int UT_mem_shlcmd(   int argc, char *argv[]) {
    UT_mem_pool *pool;
    UT_malloc_rec *rec;
    unsigned bufs_used, i, j;
    double kb_used;
    double grand_kb_used=0;
    char *cols[] = { "pool                      ",   " bytes/buf", 
                     "      bufs", "          kb",   NULL };

    switch (argc) {
    case 1:
            UT_shl_hdr(cols);
            pool = UT_mem_global.pools;
            while (pool) {
                    bufs_used = 0;
                    for(rec=pool->mars;rec;rec=rec->hh.next) 
                        bufs_used += rec->num_bufs;

                    kb_used = bufs_used * pool->buf_size / 1024.0;
                    grand_kb_used += kb_used;

                    UT_shlf( "%-26.26s %10u %10u %12.1f\n",
                            pool->name, pool->buf_size, bufs_used, kb_used);
                    pool = pool->hh.next;
            }
            UT_shlf( "\n%-48.48s %12.1f\n", "Total(KB)", grand_kb_used);

            if (grand_kb_used >= 1024) {
                UT_shlf("%-48.48s %12.1f\n", "Total(MB)", grand_kb_used/1024.0);
            }

            return SHL_OK;
            break;
    case 2:
            /* if (!strcmp(argv[1],"-H")) return UT_hash_dump(); */

            /* mem -h displays summary information for the hashes */
            if (!strcmp(argv[1],"-h")) {
                    UT_hash_shlcmd(argc-1,&argv[1]);
                    return SHL_OK;
            } else if (!strcmp(argv[1],"-hkey")) {
                    UT_hkey_shlcmd(argc-1,&argv[1]);
                    return SHL_OK;
            }

            /* here if details on a specific pool requested */
            HASH_FIND_STR(UT_mem_global.pools, pool, name, argv[1]);
            if (!pool) {
                UT_shlf("no such pool\n");
                return SHL_OK;
            }

            UT_shlf("Buffer size: %d\n", pool->buf_size);
            UT_shlf("Allocations: %d\n", pool->allocd_buf_stats);
            UT_shlf("Frees      : %d\n", pool->freed_buf_stats);

            return SHL_OK;
            break;
    default:
            UT_mem_usage(0,NULL);  /* show usage */
            return SHL_OK;
            break;
    }
}


int UT_mem_usage(int argc,char*argv[]) {
    char *memh_help =
"The 'n' items in a hash are distributed into 'k' buckets. Ideally each \n"
"bucket would have contain an equal share ('n/k') of the items. The quality \n"
"hq (0=worst,1=best) measures the fraction of items whose position in their \n"
"bucket falls within the ideal length 'n/k'. I.e., for this fraction of items, \n"
"a lookup requires no more than the ideal number of steps.  Hashes \n"
"exhibit non-ideal distribution because the hash algorithm, which maps the \n"
"keys of the data to buckets, distributes some key domains more uniformly \n"
"than others. \n"
" \n"
"Besides distributing items equally among the buckets, the other goal of the \n"
"hash is to have 'enough buckets' so that each one has only a small number \n"
"of items.  The items within a bucket are scanned sequentially by traversing \n"
"a linked-list when looking for a particular item.  This hash attempts to \n"
"keep fewer than 10 items in each bucket. When an item is added that would \n"
"cause this to be exceeded, the number of buckets in the hash is doubled and \n"
"the items are redistributed. \n"
" \n"
"Rarely, a key domain hashes so non-uniformly that despite increasing the \n"
"number of buckets, items still tend to pile up in small numbers of buckets. \n"
"If this occurs (determined by a heuristic which says if half the items fall \n"
"beyond the ideal maximum bucket length) twice on consecutive expansions, the \n"
"hash's 'noexpand' flag is set to prevent further pointless bucket expansion. \n";

    if (argc == 2) {
        if (!strcmp(argv[1],"-h")) {
            UT_shlf(memh_help);
            return 0;
        }
    }
    UT_shlf("Usage:\n");
    UT_shlf("mem              --   usage summary for all memory pools\n");
    UT_shlf("mem <poolname>   --   detailed information for a pool\n");
    UT_shlf("mem -h           --   hash statistics (see 'help mem -h')\n");
    UT_shlf("mem -hkey        --   list a representative key for each hash\n");
    return 0;
}

/*******************************************************************************
 * Traverse the hash tables by getting their addresses from their memory pool, *
 * printing information about the number of buckets having 'm-n' items per bkt.*
 ******************************************************************************/
int UT_hash_shlcmd(   int argc, char *argv[]) {
        UT_hash_table**hashes,**h;
        unsigned bkt_top[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        unsigned bkt_top_sz = 11;
        unsigned bkt_hst[12]; /* one extra */
        unsigned i,sum,cnt,j,found;
        char *cols[] = {"key1_addr ", "hq ", "#items ","#buckets", 
                        "  0", "  1", "  2", "  3", "  4", "  5",
                        "  6","  7","  8","  9"," 10",">10", NULL };
        char **col;
        char str[PCT_MAXLEN];
        int wid;
        double pct;
        UT_hash_handle*hh;
        void *rep; 

        UT_shl_hdr( cols );
        hashes = (UT_hash_table**)UT_mem_get_buf_map( UTHASHPOOL );
        h=hashes;
        while(*h) {
            for(i=0;i<12;i++) bkt_hst[i] = 0;  /* zero counts */
            for(i=0, sum=0; i < (*h)->num_buckets; i++) {
                j=0; found=0;
                while (j < bkt_top_sz && !found) {
                        if ((*h)->buckets[i].count <= bkt_top[j]) found=1;
                        else j++;
                }
                bkt_hst[j]++;
                sum += (*h)->buckets[i].count;
            }

            /* Find an item in this hash (the first one we can find) and
             * use the address of that item's key as a label for the hash. */
            for(i=0, rep=NULL; i < (*h)->num_buckets && !rep; i++) {
               if ((*h)->buckets[i].hh_head) rep=(*h)->buckets[i].hh_head->key;
            }

            UT_shlf("%-10p%c", rep, ((*h)->noexpand) ? '*' : ' ');
            UT_shlf("%1.1f ", (*h)->hash_q);
            UT_shlf("%7d ", sum);
            UT_shlf("%8d ", (*h)->num_buckets);

            if (sum > 0) {
                for( j = 0; j < 12; j++) {
                   pct = bkt_hst[j] * 100.0 / (*h)->num_buckets;
                   if (bkt_hst[j] == 0) str[0] = '\0';
                   else snprintf(str, PCT_MAXLEN, "%.0f%%", pct);
                   UT_shlf("%*s ", 3, str);
                }
            }
            UT_shlf("\n");
            h++;
        }
        UT_shlf("\nHashes suffixed with '*' are expansion-inhibited.\n");
        free(hashes);
        return SHL_OK;
}


int UT_hkey_shlcmd(int argc,char*argv[]) {
        UT_hash_table**hashes,**h;
        void *key;
        int keylen,i,ascii_key;
        char *s, *sv, c;
        char *cols[] = { "key1_addr  ", "hash_head                     ",
                         "key1_len", "key1", NULL};

        UT_shl_hdr(cols);
        hashes = (UT_hash_table**)UT_mem_get_buf_map( UTHASHPOOL );
        h=hashes;
        while(*h) {
            /* Print info about the key of the first item we find in the hash */
            ascii_key=1;
            for(i=0; i < (*h)->num_buckets; i++) {
               if ((*h)->buckets[i].hh_head) {
                   key=(*h)->buckets[i].hh_head->key;
                   keylen=(*h)->buckets[i].hh_head->keylen;
                   for(i=0;i<keylen;i++) {
                       c = ((char*)key)[i];
                       if (c < 0x20 || c > 0x7e) ascii_key=0; 
                   }
                   if (ascii_key) {
                       if ( (s=(char*)malloc(keylen+1)) == NULL) 
                           UT_log(Fatal,"out of memory");
                       memcpy(s,key,keylen);
                       s[keylen]='\0';
                   } else {
                       if ( (s=(char*)malloc((keylen*2)+1)) == NULL) 
                           UT_log(Fatal,"out of memory");
                       sv = s;
                       for(i=0;i<keylen;i++) {
                           c = ((char*)key)[i];
                           sprintf(sv,"%.2x",(unsigned)c);
                           sv += 2;
                       }
                       *sv = '\0';
                   }
                   UT_shlf("%-11p %-30.30s %8d %s\n",key,(*h)->name,keylen,s);
                   free(s);
                   break;   
               }
            }


            h++;
        }
        free(hashes);
        return SHL_OK;
}

int UT_mem_init_shl( void ) {
        UT_shl_cmd_create( "mem", "memory pool usage summary",
                (UT_shlcmd *)UT_mem_shlcmd, (UT_helpcb*)UT_mem_usage);
        return 0;
}

