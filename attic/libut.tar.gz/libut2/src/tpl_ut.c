/*
Copyright (c) 2003-2006, Troy Hanson
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

static const char id[]="$Id: tpl_ut.c,v 1.4 2006/05/16 02:19:01 thanson Exp $";

#include "libut/ut_internal.h"

UT_tpl_q *UT_tpl_q_global = NULL;

/* this is the tpl_gather_cb which is invoked for each tpl when its
 * frame has been read completely. We simply add it to the fd's tpl queue.
 */
int UT_tpl_enq_one(void *img, int sz, UT_tpl_q *q) {
    UT_tpl *tpl;

    tpl = UT_pmalloc(TPL_POOL,1);
    tpl->img = UT_malloc(sz); /* copy the tpl to alloc'd memory */
    memcpy(tpl->img, img, sz);
    tpl->sz = sz;
    tpl->prev = NULL;
    tpl->next = NULL;
    DL_ADD(q->tplq,tpl);
}

/* This is a "fd readable" callback that reads tpls off the fd and
 * enqueues them for later dispatching to an app cb in the event loop.
 */
int UT_tpl_enq(int fd, char *name, int flags, UT_callback *appcb) {
    UT_tpl_q *q;

    /* look up gatherer state for this fd, create if needed */
    HASH_FIND_INT(UT_tpl_q_global, q, fd, &fd);
    if (q == NULL) {
        q = UT_pmalloc(TPL_Q_POOL,1);  
        q->fd = fd;
        q->tplq = NULL;
        q->gs = NULL;
        q->appcb = appcb;
        q->free_after_deq = 0;
        HASH_ADD_INT(UT_tpl_q_global, fd, q);
    }
    
    if ( tpl_gather(fd, &q->gs, (tpl_gather_cb*)UT_tpl_enq_one, q) <= 0) {
        q->free_after_deq=1;
        /* close(fd); */  /* App should do this in NULL final callback */
        UT_fd_unreg(fd);
    } 
}

UT_API int UT_tpl_deq_reg(int fd, char *name, UT_tpl_deq_cb *cb, void *data) {
    UT_callback *appcb;

    appcb = UT_pmalloc(CBDATA,1);
    appcb->cb.tplcb = cb;      /* app cb to call in event loop if tpl q ready */
    appcb->data = data;        /* data to pass back to app cb */
    UT_fd_reg(fd, name, (UT_fd_cb*)UT_tpl_enq, appcb, UTFD_R);
}

int UT_tpl_update() {
    UT_tpl_q *q, *qnxt;
    UT_tpl *tpl,*tplnxt;

    for(q=UT_tpl_q_global; q; q=qnxt) {
        qnxt = q->hh.next;
        if (q->tplq) {
            /* invoke app's UT_tpl_deq_cb, giving it the tpl queue */
            (q->appcb->cb.tplcb)(q->fd, q->tplq, q->appcb->data);
            for(tpl=q->tplq; tpl; tpl=tplnxt) {
                tplnxt = tpl->next;
                UT_free(tpl->img);
                UT_pfree(TPL_POOL,tpl);
            }
            q->tplq = NULL;
        }
        if (q->free_after_deq) {
            HASH_DEL(UT_tpl_q_global,q);
            /* invoke app cb one last time, with special NULL signifier */
            (q->appcb->cb.tplcb)(q->fd, NULL, q->appcb->data);
            UT_pfree(CBDATA, q->appcb);
            UT_pfree(TPL_Q_POOL,q);
        }

    }
}

void UT_tpl_init() {
    UT_pcreate( TPL_Q_POOL, sizeof(UT_tpl_q));
    UT_pcreate( TPL_POOL, sizeof(UT_tpl));
    /* TODO modify hooks in tpl_hook */
}
