/*
Copyright (c) 2005-2006, Troy Hanson     http://tpl.sourceforge.net
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef TPL_H
#define TPL_H 

#include <sys/types.h>  /* size_t */
#include <inttypes.h>   /* uint32_t */

#if defined __cplusplus
extern "C" {
#endif

#define TPL_API

#define TPL_MAGIC "tpl"

/* values for the flags byte that appears after the magic prefix */
#define TPL_FL_BIGENDIAN  (1 << 0)

/* bit flags used at runtime, not stored in the tpl */
#define TPL_FILE    (1 << 0)
#define TPL_MEM     (1 << 1)
#define TPL_FD      (1 << 2)
#define TPL_RDONLY  (1 << 3)  /* tpl was loaded (for unpacking) */
#define TPL_WRONLY  (1 << 4)  /* app has initiated tpl packing  */
#define TPL_XENDIAN (1 << 5)  /* swap endianness when unpacking */
#define TPL_UFREE   (1 << 6)  /* free mem img when freeing tpl  */

/* char values for node type */
#define TPL_TYPE_ROOT   0
#define TPL_TYPE_INT32  1
#define TPL_TYPE_UINT32 2
#define TPL_TYPE_BYTE   3
#define TPL_TYPE_STR    4
#define TPL_TYPE_ARY    5
#define TPL_TYPE_BIN    6
#define TPL_TYPE_DOUBLE 7


/* error codes */
#define ERR_NOT_MINSIZE        (-1)
#define ERR_MAGIC_MISMATCH     (-2)
#define ERR_INCONSISTENT_SZ    (-3)
#define ERR_FMT_INVALID        (-4)
#define ERR_FMT_MISSING_NUL    (-5)
#define ERR_FMT_MISMATCH       (-6)
#define ERR_INCONSISTENT_SZ2   (-7)
#define ERR_INCONSISTENT_SZ3   (-8)

/* Hooks for error logging, memory allocation functions and other config 
 * parameters to allow customization.
 */
typedef int (tpl_print_fcn)(const char *fmt, ...);
typedef void *(tpl_malloc_fcn)(size_t sz);
typedef void *(tpl_realloc_fcn)(void *ptr, size_t sz);
typedef void (tpl_free_fcn)(void *ptr);
typedef void (tpl_fatal_fcn)(char *fmt, ...);

typedef struct tpl_hook_t {
    tpl_print_fcn *oops;
    tpl_malloc_fcn *malloc;
    tpl_realloc_fcn *realloc;
    tpl_free_fcn *mfree;
    tpl_fatal_fcn *fatal;
    int fd_tpl_img_maxlen;
} tpl_hook_t;

typedef struct tpl_pidx {
    struct tpl_node *node;
    struct tpl_pidx *next;
} tpl_pidx;

typedef struct tpl_node {
    char type;
    void *addr;
    void *data;                /* r:tpl_root_data*. A:tpl_atyp*. ow:szof type */
    struct tpl_node *children; /* child linked-list head */
    struct tpl_node *next;     /* next child of parent */
    struct tpl_node *parent;   /* parent of this node */
} tpl_node;

typedef struct tpl_atyp {
    uint32_t num;    /* num elements */
    size_t sz;  /* size of each backbone's datum */
    struct tpl_backbone *bb,*bbtail; 
    void *cur;                       
} tpl_atyp;

typedef struct tpl_backbone {
    void *data;
    struct tpl_backbone *next;
} tpl_backbone;

typedef struct tpl_mmap_rec {
    int fd;
    void *text;
    off_t text_sz;
} tpl_mmap_rec;

typedef struct tpl_root_data {
    int flags;
    tpl_pidx *pidx;
    tpl_mmap_rec mmap;
} tpl_root_data;

struct tpl_type_t {
    char idx;
    char c;
    int sz;
};

/* used when un/packing 'B' type (binary buffers) */

typedef struct tpl_bin {
    void *addr;
    uint32_t sz;
} tpl_bin;

/* The next structure is used for async/piecemeal reading of tpl images */

typedef struct tpl_gather_t {
    char *img;
    int len;
} tpl_gather_t;

/* Callback used when tpl_gather has read a full tpl image */
typedef int (tpl_gather_cb)(void *img, int sz, void *data);

/* Prototypes */
TPL_API tpl_node *tpl_map(char *fmt,...);       /* define tpl using format, addresses */
TPL_API int tpl_free(tpl_node *r);              /* free a tpl map */
TPL_API int tpl_pack(tpl_node *r, int i);       /* pack the n'th packable */
TPL_API int tpl_unpack(tpl_node *r, int i);     /* unpack the n'th packable */
TPL_API int tpl_dump(tpl_node *r, int mode, ...); /* serialize to mem or file */
TPL_API int tpl_load(tpl_node *r, int mode, ...); /* set mem/file to unpack */

TPL_API int tpl_Alen(tpl_node *r, int i);        /* array len of packable i */

TPL_API int tpl_packN(tpl_node *r, int i, int count, int stride);
TPL_API int tpl_unpackN(tpl_node *r, int i, int count, int stride);

/* tpl_acquire reads a single tpl image from a blocking fd then returns. */
/* tpl_gather can be used by select()-driven apps to read tpl images piecemeal */
TPL_API int tpl_acquire(int fd, void **img, int *sz);
TPL_API int tpl_gather( int fd, tpl_gather_t **gs, tpl_gather_cb *cb, void *data);

/* Internal prototypes */
tpl_node *tpl_node_new(tpl_node *parent);
tpl_node *tpl_find_i(tpl_node *n, int i);
void *tpl_cpv(void *datav, void *data, size_t sz);
void *tpl_extend_backbone(tpl_node *n);
char *tpl_fmt(tpl_node *n);
void *tpl_dump_atyp(tpl_node *n, tpl_atyp* at, void *dv);
int tpl_sersz(tpl_node *n,tpl_atyp *at);
void tpl_free_atyp(tpl_node *n,tpl_atyp *atyp);
int tpl_dump_to_mem(tpl_node *r, void *addr, int sz);
int tpl_mmap_file(char *filename, tpl_mmap_rec *map_rec);
int tpl_mmap_output_file(char *filename, off_t sz, void **text_out);
int tpl_cpu_bigendian(void);
int tpl_needs_endian_swap(void *);
void tpl_byteswap(void *word, int len);
void tpl_fatal(char *fmt, ...);

#if defined __cplusplus
    }
#endif

#endif /* TPL_H */

