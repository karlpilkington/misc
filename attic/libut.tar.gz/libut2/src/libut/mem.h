/*
Copyright (c) 2003-2005, Troy Hanson
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************
 * mem.h                                                                      *
 *****************************************************************************/
#define POOL_NAME_MAX_LEN 100

#define MALLOC_FAILED 1
#define BAD_POOL_NAME 2

#define GENPOOL "generic"
#define UTHASHPOOL "hash_tbl"

typedef struct UT_malloc_rec {
    void *addr;
    unsigned num_bufs;
    UT_hash_handle hh;
} UT_malloc_rec;

typedef struct UT_mem_pool {
        char name[POOL_NAME_MAX_LEN];
        unsigned buf_size;
        unsigned freed_buf_stats;
        unsigned allocd_buf_stats;
        UT_malloc_rec *mars;
        struct UT_hash_handle hh;
} UT_mem_pool;


typedef struct UT_mem_global_type {
        UT_mem_pool *pools;
} UT_mem_global_type;

void UT_mem_init(void);
void **UT_mem_get_buf_map( char *poolname);
int UT_hash_rescale(UT_hash_table *);
double UT_hash_quality(UT_hash_table *);
