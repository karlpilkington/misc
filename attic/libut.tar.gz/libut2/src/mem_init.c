/*
Copyright (c) 2003-2006, Troy Hanson
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <string.h>
#include <stdlib.h>
#include "libut/ut_internal.h"

extern int UT_mem_init_shl(void);
extern UT_mem_global_type UT_mem_global;

/* Use straight malloc in this source file (only) so HASH_ADD can create
 * UT_hash_table's before their memory pool is established. UT_mem_init()
 * establishes that memory pool as well as the generic pool. 
 */
#undef uthash_tbl_malloc
#define uthash_tbl_malloc(sz) malloc(sz)

void UT_mem_init() {
    UT_mem_pool *pool;
    UT_malloc_rec *alloc1, *alloc2;

    if (!(pool = (UT_mem_pool *)malloc(sizeof(UT_mem_pool))))
        UT_log(Fatal, "out of memory");

    /* Set up the basic information for this pool, name etc. */     
    UT_strncpy( pool->name, UTHASHPOOL, POOL_NAME_MAX_LEN);
    pool->buf_size = sizeof(UT_hash_table);
    pool->allocd_buf_stats = 0;
    pool->freed_buf_stats = 0;
    pool->mars = NULL;

    /* malloc's a hash table as a side effect, since its the first pool */
    HASH_ADD(hh,UT_mem_global.pools,name,strlen(pool->name),pool);

    /* Manually create the allocation record for the hash table
     * that was created (keyed on pool name) within the above HASH_ADD. */
    alloc1 = (UT_malloc_rec*)malloc(sizeof(UT_malloc_rec));
    if (alloc1 == NULL) UT_log(Fatal, "out of memory");
    alloc1->addr = pool->hh.tbl;
    alloc1->num_bufs = 1;

    /* malloc's a hash table as a side effect, since its the first alloc */
    HASH_ADD(hh,pool->mars,addr,sizeof(void*),alloc1);

    /* Lastly create one more allocation record for the hash table
     * that was created (keyed on malloc addrs) within the above HASH_ADD. */
    alloc2 = (UT_malloc_rec*)malloc(sizeof(UT_malloc_rec));
    if (alloc2 == NULL) UT_log(Fatal, "out of memory");
    alloc2->addr = pool->mars->hh.tbl;
    alloc2->num_bufs = 1;

    HASH_ADD(hh,pool->mars,addr,sizeof(void*),alloc2);

    UT_pcreate(GENPOOL,sizeof(char));
    UT_mem_init_shl();
}
