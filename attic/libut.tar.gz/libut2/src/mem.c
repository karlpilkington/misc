/*
Copyright (c) 2003-2006, Troy Hanson
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*******************************************************************************
* mem.c                                                                        *
* Copyright (c) 2003-2006 Troy Hanson                                          *
*******************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "libut/ut_internal.h"


#define MALLOC_FAILED 1
#define BAD_POOL_NAME 2


/* A global structure used to keep the master memory list */
UT_mem_global_type UT_mem_global = { 
    .pools = NULL
};


/******************************************************************************
 * UT_pcreate()                                                       *
 *****************************************************************************/
UT_API void UT_pcreate( char *poolname, int buf_size) {
    UT_mem_pool *pool, *pooltemp;

    if (!(pool = (UT_mem_pool *)malloc(sizeof(UT_mem_pool))))
        UT_log(Fatal, "out of memory");

    /* Set up the basic information for this pool, name etc. */     
    UT_strncpy( pool->name, poolname, POOL_NAME_MAX_LEN);
    pool->buf_size = buf_size;
    pool->allocd_buf_stats = 0;
    pool->freed_buf_stats = 0;
    pool->mars = NULL;

    /* This pool is all set up. Add it to the global list of pools. */
    HASH_ADD_STR( UT_mem_global.pools, name, pool);
}


UT_API void *UT_pmalloc( char *poolname, int bufs_rqstd ) {
    UT_mem_pool *pool;
    UT_malloc_rec *rec;
    void *bufaddr;

    if (bufs_rqstd == 0) {
        UT_log(Error, "Bad mem allocation request for 0 buffers");
        return NULL;
    }

    HASH_FIND_STR(UT_mem_global.pools, pool, name, poolname);
    if (!pool) UT_log(Fatal, "bad pool name in buf alloc [%s]", poolname);

    if ( (bufaddr = malloc(pool->buf_size * bufs_rqstd)) == NULL) {
        UT_log(Fatal, "out of memory");
    }

    if ( (rec = malloc(sizeof(UT_malloc_rec))) == NULL) {
        free(bufaddr);
        UT_log(Fatal, "out of memory");
    }

    rec->addr = bufaddr;
    rec->num_bufs = bufs_rqstd;
    HASH_ADD(hh, pool->mars, addr, sizeof(void*), rec );
    pool->allocd_buf_stats += bufs_rqstd;
    return bufaddr;
}

UT_API void UT_pfree( char *poolname, void *buf) {
    UT_mem_pool *pool;
    UT_malloc_rec *rec;

    HASH_FIND_STR(UT_mem_global.pools, pool, name, poolname);
    if (!pool) UT_log(Fatal, "bad pool name in buf alloc [%s]", poolname);

    HASH_FIND(hh, pool->mars, rec, addr, &buf, sizeof(void*)); 
    if (!rec) {
        UT_log( Error, "Can't free unallocated buf from %s", poolname);
        return;
    }

    pool->freed_buf_stats += rec->num_bufs;
    HASH_DEL( pool->mars, rec);
    free(rec->addr);
    free(rec);
}

UT_API void *UT_malloc( size_t size) {
    return UT_pmalloc(GENPOOL, size);
}

UT_API void UT_free( void *addr) {
    UT_pfree(GENPOOL,addr);
}

/* Find the memory pool, and create a malloc'd array of pointers
 * to all of the pool's in-use buffers. The caller must free() 
 * the pool when done. This function should be used very carefully
 * because the buffer pointers are only valid until something 
 * modifies that pool, i.e. use these pointers only as long as
 * you know the pool hasn't been modified yet. It is best to do
 * whatever needs to be done on them and then immediately free
 * the buffer pointers and then return, keeping no references. */
void**UT_mem_get_buf_map(char *poolname) {
    UT_mem_pool *pool;
    UT_malloc_rec *rec;
    unsigned i,bufs_used=0;
    void **buflist,**b;

    HASH_FIND_STR(UT_mem_global.pools, pool, name, poolname);
    if (!pool) return NULL;
     
    for(rec = pool->mars; rec; rec=rec->hh.next) bufs_used += rec->num_bufs;
    if ( (buflist = (void**)malloc( (bufs_used+1) * sizeof(void*) )) == NULL)
        UT_log(Fatal,"out of memory"); 

    b=buflist;
    for(rec = pool->mars; rec; rec=rec->hh.next) {
        for(i=0; i<rec->num_bufs; i++) {
            *b++ = (void*)((long)rec->addr + i*(pool->buf_size));
        }
    }
    *b++ = NULL; 
    return buflist;
}

