/*
Copyright (c) 2003-2006, Troy Hanson
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*****************************************************************************
 *  ut_iob.c                                                                 *
 *  Functions for input-output buffers. These are used when gathering input  *
 *  in various-sized chunks during a network read, for example, but can also *
 *  be used to construct an output buffer one chunk at a time.               *
 *  An iob is simply a linked list of malloc'd buffers.                      *
 ****************************************************************************/
static const char id[]="$Id: iob.c,v 1.21 2006/05/16 02:33:45 thanson Exp $";

#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>
#include "libut/ut_internal.h"


/*
 * UT_iob_free()
 * frees the iob chain whose head is given.
 */
int UT_iob_free(UT_iob *iob_head) {
    UT_iob *iob,*nxt;

    for(iob=iob_head;iob;iob=nxt) {
        nxt = iob->next;
        if (iob->to_free) free(iob->to_free);
        UT_pfree(UTIOB, iob);
    }
}

/****************************************************************************
*  UT_iob_writefd                                                           *
*  Writes the io buffer list (iob) to a file descriptor                     *
****************************************************************************/
int UT_iob_writefd(UT_iob *iob, int fd) {
    int rc,n=0;

    while (iob) {
        if ( (rc = UT_fd_write(fd, iob->buf, iob->len)) == -1 ) {
            UT_log(Error, "iob write failed: %d bytes written, fd %d", n, fd);
            return -1;
        }
        else n += rc;
        iob = iob->next;
    }
    return n;
}

/******************************************************************************
 * UT_iob_append()                                                            *
 * This appends a binary buffer of the given length to the iob                *
 *****************************************************************************/
int UT_iob_append(UT_iob **iob_head, void *b, size_t n ) {
    UT_iob *iob,*tail;
    void *buf;
    int mknew,spc_left;

    if (n <= 0) return -1; 

    if (*iob_head == NULL) mknew=1;
    else {
        tail = (*iob_head)->prev;
        if (tail->buf == tail->bi) { 
            spc_left = IOB_BUILTIN_BUFLEN - tail->len;
            mknew = (spc_left >= n) ? 0 : 1;
        } else mknew=1;
    }

    if (mknew) {
        /* make new iob */
        iob = UT_pmalloc(UTIOB,1);
        memset(iob,0,sizeof(UT_iob));
        if (n > IOB_BUILTIN_BUFLEN) {
            iob->buf = malloc(n);
            iob->to_free = iob->buf;
        } else {
            iob->buf = iob->bi;
            iob->to_free = NULL; 
        }
        memcpy(iob->buf,b,n);
        iob->len = n;
        DL_ADD(*iob_head, iob);
    } else {
        /* use space in existing iob */
        memcpy(&tail->buf[tail->len], b, n);
        tail->len += n;
    }

    return 0;
}

/****************************************************************************
*  UT_iob_printf                                                            *
*  Append the given printf-style variable-argument string to the iob.       *
****************************************************************************/
int UT_iob_printf(UT_iob **iob_head, char *fmt, ...) {
    va_list ap;
    char *s;
    UT_iob *iob;

    va_start(ap, fmt);
    if ( (s = UT_dsprintf(fmt, ap)) == NULL) {
        UT_log(Fatal,"out of memory");
    }
    va_end(ap);

    iob = UT_pmalloc(UTIOB,1);
    memset(iob,0,sizeof(UT_iob));
    iob->buf = s;
    iob->to_free = s;
    iob->len = strlen(s);

    DL_ADD(*iob_head, iob);
    return 0;
}
/******************************************************************************
 * UT_iob_len()                                                               *
 * utility function to get the total length of an IOB                         *
 *****************************************************************************/
size_t UT_iob_len( UT_iob *iob ) {
    size_t len = 0;

    while (iob) {
        len += iob->len;
        iob=iob->next;
    }

    return len;
}

/******************************************************************************
 * UT_iob_flatten()                                                           *
 * Writes an iob to contiguous alloc'd memory. Caller must free() buffer.     *
 * The trailing NULL that this function adds is not counted in buffer length. *
 * The out_len parameter may be NULL if the caller does not want the length.  *
 *****************************************************************************/
char *UT_iob_flatten( UT_iob *iob, size_t *out_len) {
    char *data, *pos;
    size_t len;

    len = UT_iob_len( iob );
    if (out_len) *out_len = len;
    if ( (data = malloc(len + 1)) == NULL ) UT_log( Fatal, "malloc failure");

    pos = data;
    while (iob) {
        if (iob->len > 0) {
            memcpy(pos,iob->buf,iob->len);
            pos += iob->len;
        }
        iob=iob->next;
    }
    *pos = '\0';  /* null terminate- a convenience for string iobs */

    return data;
}

int UT_iob_init() {
    UT_pcreate( UTIOB,  sizeof(UT_iob));
}
