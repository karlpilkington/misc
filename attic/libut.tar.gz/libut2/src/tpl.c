/*
Copyright (c) 2005-2006, Troy Hanson     http://tpl.sourceforge.net
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

static const char id[]="$Id: tpl.c,v 1.5 2006/05/16 02:19:01 thanson Exp $";


#include <stdlib.h>  /* malloc */
#include <stdarg.h>  /* va_list */
#include <string.h>  /* memcpy, memset */
#include <stdio.h>   /* printf (tpl_hook.oops default function) */

#include <unistd.h>     /* for ftruncate */
#include <sys/types.h>  /* for 'open' */
#include <sys/stat.h>   /* for 'open' */
#include <fcntl.h>      /* for 'open' */
#include <errno.h>
#include <sys/mman.h>   /* mmap */
#include <inttypes.h>   /* uint32_t, uint64_t, etc */

#include "tpl.h"

#define TPL_LL_ADD(head,tmp,add) \
 do {                            \
    tmp = head;                  \
    if (tmp) {                   \
        while ((tmp)->next)      \
            tmp=(tmp)->next;     \
        (tmp)->next=add;         \
    } else head=add;             \
 } while (0)

#define TPL_GATHER_BUFLEN 8192

/* Hooks for customizing tpl mem alloc, error handling, etc. Set defaults. */
tpl_hook_t tpl_hook = {
    .oops = printf,
    .malloc = malloc,
    .realloc = realloc,
    .mfree = free,
    .fatal = tpl_fatal,
    .fd_tpl_img_maxlen = 0 /* max tpl size (bytes) for tpl_gather/tpl_acquire */
};

struct tpl_type_t tpl_types[] = {
    /* Order below must match TPL_TYPE_x from tpl.h */
    {TPL_TYPE_ROOT,   'r', 0},
    {TPL_TYPE_INT32,  'i', sizeof(int32_t)},
    {TPL_TYPE_UINT32, 'u', sizeof(uint32_t)},
    {TPL_TYPE_BYTE,   'b', sizeof(char)},
    {TPL_TYPE_STR,    's', 0},
    {TPL_TYPE_ARY,    'A', 0},
    {TPL_TYPE_BIN,    'B', 0},
    {TPL_TYPE_DOUBLE, 'd', 8},
};

tpl_node *tpl_node_new(tpl_node *parent) {
    tpl_node *n;
    if ((n=tpl_hook.malloc(sizeof(tpl_node))) == NULL) {
        tpl_hook.fatal("out of memory\n");
    }
    n->addr=NULL;
    n->data=NULL;
    n->children=NULL;
    n->next=NULL;
    n->parent=parent;
    return n;
}

TPL_API tpl_node *tpl_map(char *fmt,...) {
    int lparen_level=0,expect_lparen=0,t;
    char *c;
    va_list ap;
    tpl_node *root,*parent,*n,*ntmp;
    tpl_pidx *pidx, *tpl_pidxmp;

    root = tpl_node_new(NULL);
    root->type = TPL_TYPE_ROOT; 
    root->data = (tpl_root_data*)tpl_hook.malloc(sizeof(tpl_root_data));
    if (!root->data) tpl_hook.fatal("out of memory\n");
    memset((tpl_root_data*)root->data,0,sizeof(tpl_root_data));
    parent=root;
    va_start(ap,fmt);

    c=fmt;
    while (*c != '\0') {
        switch (*c) {
            case 'b':
            case 'i':
            case 'u':
            case 'd':
                if (*c=='b') t=TPL_TYPE_BYTE;
                if (*c=='i') t=TPL_TYPE_INT32;
                if (*c=='u') t=TPL_TYPE_UINT32;
                if (*c=='d') t=TPL_TYPE_DOUBLE;

                if (expect_lparen) goto fail;
                n = tpl_node_new(parent);
                n->type = t;
                n->addr = (void*)va_arg(ap,void*);
                n->data = tpl_hook.malloc(tpl_types[t].sz);
                if (!n->data) tpl_hook.fatal("out of memory\n");
                if (n->parent->type == TPL_TYPE_ARY) 
                    ((tpl_atyp*)(n->parent->data))->sz += sizeof(tpl_types[t].sz);
                TPL_LL_ADD(parent->children,ntmp,n);
                break;
            case 'B':
                if (expect_lparen) goto fail;
                n = tpl_node_new(parent);
                n->type = TPL_TYPE_BIN;
                n->addr = (tpl_bin*)va_arg(ap,void*);
                n->data = tpl_hook.malloc(sizeof(tpl_bin*));
                if (!n->data) tpl_hook.fatal("out of memory\n");
                *((tpl_bin**)n->data) = NULL;
                if (n->parent->type == TPL_TYPE_ARY) 
                    ((tpl_atyp*)(n->parent->data))->sz += sizeof(tpl_bin);
                TPL_LL_ADD(parent->children,ntmp,n);
                break;
            case 's':
                if (expect_lparen) goto fail;
                n = tpl_node_new(parent);
                n->type = TPL_TYPE_STR;
                n->addr = (char**)va_arg(ap,void*);
                n->data = tpl_hook.malloc(sizeof(char*));
                if (!n->data) tpl_hook.fatal("out of memory\n");
                *(char**)(n->data) = NULL;
                if (n->parent->type == TPL_TYPE_ARY) 
                    ((tpl_atyp*)(n->parent->data))->sz += sizeof(void*);
                TPL_LL_ADD(parent->children,ntmp,n);
                break;
            case 'A':
                n = tpl_node_new(parent);
                n->type = TPL_TYPE_ARY;
                TPL_LL_ADD(parent->children,ntmp,n);
                parent = n;
                expect_lparen=1;
                pidx = (tpl_pidx*)tpl_hook.malloc(sizeof(tpl_pidx));
                if (!pidx) tpl_hook.fatal("out of memory\n");
                pidx->node = n;
                pidx->next = NULL;
                TPL_LL_ADD(((tpl_root_data*)(root->data))->pidx,tpl_pidxmp,pidx);
                /* set up the A's tpl_atyp */
                n->data = (tpl_atyp*)tpl_hook.malloc(sizeof(tpl_atyp));
                if (!n->data) tpl_hook.fatal("out of memory\n");
                ((tpl_atyp*)(n->data))->num = 0;
                ((tpl_atyp*)(n->data))->sz = 0;
                ((tpl_atyp*)(n->data))->bb = NULL;
                ((tpl_atyp*)(n->data))->bbtail = NULL;
                ((tpl_atyp*)(n->data))->cur = NULL;
                if (n->parent->type == TPL_TYPE_ARY) 
                    ((tpl_atyp*)(n->parent->data))->sz += sizeof(void*);
                break;
            case ')':
                lparen_level--;
                if (lparen_level < 0) goto fail;
                if (*(c-1) == '(') goto fail;
                parent = parent->parent; 
                break;
            case '(':
                if (!expect_lparen) goto fail;
                expect_lparen=0;
                lparen_level++;
                break;
            default:
                tpl_hook.oops("unsupported option %c\n", *c);
                goto fail;
        }
        c++;
    }
    if (lparen_level != 0) goto fail;
    va_end(ap);
    return root;

fail:
    va_end(ap);
    tpl_hook.oops("failed to parse %s\n", fmt);
    tpl_hook.mfree(root);
    return NULL;
}

int tpl_unmap_file( tpl_mmap_rec *mr) {

    if ( munmap( mr->text, mr->text_sz ) == -1 ) {
        tpl_hook.oops("Failed to munmap: %s\n", strerror(errno));
    }
    close(mr->fd);
    mr->text = NULL;
    mr->text_sz = 0;
    return 0;
}

TPL_API int tpl_free(tpl_node *r) {
    int mmap_bits = (TPL_RDONLY|TPL_FILE);
    int ufree_bits = (TPL_MEM|TPL_UFREE);
    tpl_node *nxtc,*c;
    int find_next_node=0,looking,go_up;
    tpl_pidx *pidx,*pidx_nxt;

    /* For mmap'd files, or for 'ufree' memory images , do appropriate release */
    if ((((tpl_root_data*)(r->data))->flags & mmap_bits) == mmap_bits) {
        tpl_unmap_file( &((tpl_root_data*)(r->data))->mmap); 
    } else if ((((tpl_root_data*)(r->data))->flags & ufree_bits) == ufree_bits) {
        tpl_hook.mfree( ((tpl_root_data*)(r->data))->mmap.text );
    }

    c = r->children;
    if (c) {
        while(c->type != TPL_TYPE_ROOT) {    /* loop until we come back to root node */
            switch (c->type) {
                case TPL_TYPE_BIN:
                    /* free any binary buffer hanging from tpl_bin */
                    if ( *((tpl_bin**)(c->data)) ) {
                        if ( (*((tpl_bin**)(c->data)))->addr ) {
                            tpl_hook.mfree( (*((tpl_bin**)(c->data)))->addr );
                        }
                        tpl_hook.mfree(*((tpl_bin**)c->data)); /* free tpl_bin */
                    }
                    tpl_hook.mfree(c->data);  /* free tpl_bin* */
                    find_next_node=1;
                    break;
                case TPL_TYPE_STR:
                    /* free any packed (copied) string */
                    if (*(char**)(c->data)) tpl_hook.mfree(*(char**)(c->data)); 
                    tpl_hook.mfree(c->data);
                    find_next_node=1;
                    break;
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                    tpl_hook.mfree(c->data);
                    find_next_node=1;
                    break;
                case TPL_TYPE_ARY:
                    tpl_free_atyp(c,c->data);
                    c = c->children; 
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }

            if (find_next_node) {
                find_next_node=0;
                looking=1;
                while(looking) {
                    if (c->next) {
                        nxtc=c->next;
                        tpl_hook.mfree(c);
                        c=nxtc;
                        looking=0;
                    } else {
                        if (c->type == TPL_TYPE_ROOT) break; /* root node */
                        else {
                            nxtc=c->parent;
                            tpl_hook.mfree(c);
                            c=nxtc;
                        }
                    }
                }
            }
        }
    }

    /* free root */
    for(pidx=((tpl_root_data*)(r->data))->pidx; pidx; pidx=pidx_nxt) {
        pidx_nxt = pidx->next;
        tpl_hook.mfree(pidx);
    }
    tpl_hook.mfree(r->data);  /* tpl_root_data */
    tpl_hook.mfree(r);
}


/* Find the i'th packable ('A' node) */
tpl_node *tpl_find_i(tpl_node *n, int i) {
    int j=0;
    tpl_pidx *pidx;
    if (n->type != TPL_TYPE_ROOT) return NULL;
    if (i == 0) return n;  /* packable 0 is root */
    for(pidx=((tpl_root_data*)(n->data))->pidx; pidx; pidx=pidx->next) {
        if (++j == i) return pidx->node;
    }
    return NULL;
}

void *tpl_cpv(void *datav, void *data, size_t sz) {
    memcpy(datav,data,sz);
    return (void*)((long)datav + sz);
}

void *tpl_extend_backbone(tpl_node *n) {
    tpl_backbone *bb;
    bb = (tpl_backbone*)tpl_hook.malloc(sizeof(tpl_backbone));
    if (!bb) tpl_hook.fatal("out of memory\n");
    bb->data = tpl_hook.malloc( ((tpl_atyp*)(n->data))->sz );
    if (!bb->data) tpl_hook.fatal("out of memory\n");
    memset(bb->data,0,((tpl_atyp*)(n->data))->sz);
    bb->next = NULL;
    /* Add the new backbone to the tail, also setting head if necessary  */
    if (((tpl_atyp*)(n->data))->bb == NULL) {
        ((tpl_atyp*)(n->data))->bb = bb;
        ((tpl_atyp*)(n->data))->bbtail = bb;
    } else {
        ((tpl_atyp*)(n->data))->bbtail->next = bb;
        ((tpl_atyp*)(n->data))->bbtail = bb;
    }

    ((tpl_atyp*)(n->data))->num++;
    return bb->data;
}

/* Get the format string corresponding to a given tpl (root node) */
/* Caller must free the returned string. */
char *tpl_fmt(tpl_node *n) {
    int len=0,done=0;
    tpl_node *c;
    int find_next_node=0,looking;
    char *fmt,*fmtv;

    /* figure size of output string */
    c = n;
    while (!done) {
        if (c) {
            switch (c->type) {
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_BIN:
                case TPL_TYPE_STR:
                    len += 1;
                    find_next_node=1;
                    break;
                case TPL_TYPE_ROOT:
                    c = c->children;
                    break;
                case TPL_TYPE_ARY:
                    len += 3;
                    c = c->children;
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
            if (find_next_node) {
                find_next_node=0;
                looking=1;
                while(looking && !done) {
                    if (c->next) {
                        c=c->next;
                        looking=0;
                    } else {
                        if (c->type == TPL_TYPE_ROOT) done=1; /* root node */
                        else c=c->parent;
                    }
                }
            }
        }
    }
    len += 1; /* nul terminator */
    if ( (fmt = tpl_hook.malloc(len)) == NULL) tpl_hook.fatal("out of memory\n");
    memset(fmt,0,len);

    done=0;
    c = n;
    fmtv = fmt;
    while (!done) {
        if (c) {
            switch (c->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_BIN:
                case TPL_TYPE_STR:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    *fmtv++ = tpl_types[c->type].c;
                    find_next_node=1;
                    break;
                case TPL_TYPE_ROOT:
                    c = c->children;
                    break;
                case TPL_TYPE_ARY:
                    *fmtv++ = 'A';
                    *fmtv++ = '(';
                    c = c->children;
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
            if (find_next_node) {
                find_next_node=0;
                looking=1;
                while(looking && !done) {
                    if (c->next) {
                        c=c->next;
                        looking=0;
                    } else {
                        if (c->type == TPL_TYPE_ROOT) done=1; /* root node */
                        else {
                            c=c->parent;
                            if (c->type == TPL_TYPE_ARY) *fmtv++ = ')';
                        }
                    }
                }
            }
        }
    }
    *fmtv++ = '\0';

    return fmt;
}

/* called when serializing an 'A' type node into a buffer which has
 * already been set up with the proper space. The backbone is walked
 * which was obtained from the tpl_atyp header passed in. 
 */
void *tpl_dump_atyp(tpl_node *n, tpl_atyp* at, void *dv) {
    tpl_backbone *bb;
    tpl_node *c;
    void *datav;
    uint32_t slen;

    /* handle 'A' nodes */
    dv = tpl_cpv(dv,&at->num,sizeof(uint32_t));  /* array len */
    for(bb=at->bb; bb; bb=bb->next) {
        datav = bb->data;
        for(c=n->children; c; c=c->next) {
            switch (c->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    dv = tpl_cpv(dv,datav,tpl_types[c->type].sz);
                    datav = (void*)((long)datav + tpl_types[c->type].sz);
                    break;
                case TPL_TYPE_BIN:
                    /* dump the buffer length followed by the buffer */
                    slen = (*(tpl_bin**)datav)->sz;
                    dv = tpl_cpv(dv,&slen,sizeof(uint32_t));
                    dv = tpl_cpv(dv,(*(tpl_bin**)datav)->addr,slen);
                    datav = (void*)((long)datav + sizeof(tpl_bin*));
                    break;
                case TPL_TYPE_STR:
                    /* dump the string length followed by the string */
                    slen = strlen(*(char**)datav);
                    dv = tpl_cpv(dv,&slen,sizeof(uint32_t));
                    dv = tpl_cpv(dv,*(char**)datav,slen);
                    datav = (void*)((long)datav + sizeof(char*));
                    break;
                case TPL_TYPE_ARY:
                    dv = tpl_dump_atyp(c,*(tpl_atyp**)datav,dv);
                    datav = (void*)((long)datav + sizeof(void*));
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
        }
    }
    return dv;
}

/* figure the size needed to serialize the subtree rooted at this node */
int tpl_sersz(tpl_node *n,tpl_atyp *at) {
    tpl_backbone *bb;
    tpl_node *c;
    int sz=0,slen;
    void *datav;
    char *fmt;

    /* handle the root node */
    if (n->type == TPL_TYPE_ROOT) {
        for(c=n->children; c; c=c->next) {
            switch (c->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    sz += tpl_types[c->type].sz;
                    break;
                case TPL_TYPE_BIN:
                    sz += sizeof(uint32_t);  /* binary buf len */
                    sz += (*(tpl_bin**)(c->data))->sz; 
                    break;
                case TPL_TYPE_STR:
                    sz += sizeof(uint32_t);  /* string len */
                    sz += strlen(*((char**)(c->data))); 
                    break;
                case TPL_TYPE_ARY:
                    sz += sizeof(uint32_t);  /* array len */
                    sz += tpl_sersz(c, (tpl_atyp*)c->data);
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
        }
        sz += sizeof(uint32_t); /* tpl leading length */
        fmt = tpl_fmt(n);
        sz += strlen(fmt) + 1;  /* fmt + NUL-terminator */
        free(fmt);
        sz += 4;           /* 'tpl' magic prefix + flags byte */
        return sz;
    }

    /* handle 'A' nodes */
    for(bb=at->bb; bb; bb=bb->next) {
        datav = bb->data;
        for(c=n->children; c; c=c->next) {
            switch (c->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    sz += tpl_types[c->type].sz;
                    datav = (void*)((long)datav + tpl_types[c->type].sz);
                    break;
                case TPL_TYPE_BIN:
                    sz += sizeof(uint32_t);     /* buffer len */
                    slen = (*(tpl_bin**)datav)->sz;
                    sz += slen;                 /* buffer itself */
                    datav = (void*)((long)datav + sizeof(tpl_bin*));
                    break;
                case TPL_TYPE_STR:
                    sz += sizeof(uint32_t);     /* string len */
                    slen = strlen(*(char**)datav);
                    sz += slen;            /* string itself w/o NUL */
                    datav = (void*)((long)datav + sizeof(char*));
                    break;
                case TPL_TYPE_ARY:
                    sz += sizeof(uint32_t);  /* array len */
                    sz += tpl_sersz(c, *(tpl_atyp**)datav);
                    datav = (void*)((long)datav + sizeof(void*));
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
        }
    }
    return sz;
}

TPL_API int tpl_dump(tpl_node *r, int mode, ...) {
    va_list ap;
    char *filename, *bufv;
    void **addr_out,*buf;
    int fd,sz,*sz_out,rc=0;

    if (((tpl_root_data*)(r->data))->flags & TPL_RDONLY) {
        tpl_hook.oops("error: tpl_dump called for a readonly tpl\n");
        return -1;
    }

    sz = tpl_sersz(r,NULL); /* compute the size needed to serialize  */

    va_start(ap,mode);
    if (mode & TPL_FILE) {
        filename = va_arg(ap,char*);
        fd = tpl_mmap_output_file(filename, sz, &buf);
        if (fd == -1) rc = -1;
        else {
            rc = tpl_dump_to_mem(r,buf,sz);
            munmap(buf, sz);
            close(fd);
        }
    } else if (mode & TPL_FD) {
        fd = va_arg(ap, int);
        if ( (buf = tpl_hook.malloc(sz)) == NULL) tpl_hook.fatal("out of memory\n");
        tpl_dump_to_mem(r,buf,sz);
        bufv = buf;
        do {
            rc = write(fd,bufv,sz);
            if (rc > 0) {
                sz -= rc;
                bufv += rc;
            } else if (rc == -1) {
                if (errno == EINTR || errno == EAGAIN) continue;
                tpl_hook.oops("error writing to fd %d: %s\n", fd, strerror(errno));
                free(buf);
                return -1;
            }
        } while (sz > 0);
        free(buf);
    } else if (mode & TPL_MEM) {
        addr_out = (void**)va_arg(ap, void*);
        sz_out = va_arg(ap, int*);
        if ( (buf = tpl_hook.malloc(sz)) == NULL) tpl_hook.fatal("out of memory\n");
        *sz_out = sz;
        *addr_out = buf;
        rc=tpl_dump_to_mem(r,buf,sz);
    } else {
        tpl_hook.oops("unsupported tpl_dump mode %d\n", mode);
        rc=-1;
    }
    va_end(ap);
    return rc;
}

/* This function expects the caller to have set up a memory buffer of 
 * adequate size to hold the serialized tpl. The sz parameter must be
 * the result of tpl_sersz(r).
 */
int tpl_dump_to_mem(tpl_node *r,void *addr,int sz) {
    uint32_t slen;
    void *dv;
    char *fmt,flags;
    tpl_node *c;

    flags = 0;
    if (tpl_cpu_bigendian()) flags |= TPL_FL_BIGENDIAN;

    dv = addr;
    dv = tpl_cpv(dv,TPL_MAGIC,3);         /* copy tpl magic prefix */
    dv = tpl_cpv(dv,&flags,1);            /* copy flags byte */
    dv = tpl_cpv(dv,&sz,sizeof(uint32_t));     /* overall length (inclusive) */
    fmt = tpl_fmt(r);
    dv = tpl_cpv(dv,fmt,strlen(fmt)+1);   /* copy format with NUL-term */
    free(fmt);

    /* serialize the tpl content, iterating over direct children of root */
    c = r->children;
    while (c) {
        switch (c->type) {
            case TPL_TYPE_BYTE:
            case TPL_TYPE_DOUBLE:
            case TPL_TYPE_INT32:
            case TPL_TYPE_UINT32:
                dv = tpl_cpv(dv,c->data,tpl_types[c->type].sz);
                break;
            case TPL_TYPE_BIN:
                slen = (*(tpl_bin**)(c->data))->sz;
                dv = tpl_cpv(dv,&slen,sizeof(uint32_t));  /* buffer len */
                dv = tpl_cpv(dv,(*(tpl_bin**)(c->data))->addr,slen); /* buf */
                break;
            case TPL_TYPE_STR:
                slen = strlen(*(char**)c->data);
                dv = tpl_cpv(dv,&slen,sizeof(uint32_t));  /* string len */
                dv = tpl_cpv(dv,*(char**)(c->data),slen); /* string */
                break;
            case TPL_TYPE_ARY:
                dv = tpl_dump_atyp(c,(tpl_atyp*)c->data,dv);
                break;
            default:
                tpl_hook.fatal("unsupported format character\n");
                break;
        }
        c = c->next;
    }

    return 0;
}

int tpl_cpu_bigendian() {
   unsigned i = 1;
   char *c;
   c = (char*)&i;
   return (c[0] == 1 ? 0 : 1);
}


/*
 * algorithm for sanity-checking a tpl image:
 * scan the tpl whilst not exceeding the buffer size (bufsz) ,
 * formulating a calculated (expected) size of the tpl based
 * on walking its data. When calcsize has been calculated it
 * should exactly match the buffer size (bufsz) and the internal
 * recorded size (intlsz)
 */
int tpl_sanity(tpl_node *r) {
    uint32_t intlsz;
    int found_nul=0,rc;
    void *d, *dv;
    char intlflags, *fmt, c, *mapfmt;
    off_t bufsz, serlen;

    d = ((tpl_root_data*)(r->data))->mmap.text;
    bufsz = ((tpl_root_data*)(r->data))->mmap.text_sz;

    dv = d;
    if (bufsz < (4 + sizeof(uint32_t) + 1)) return ERR_NOT_MINSIZE; /* min sz: magic+flags+len+nul */
    if (memcmp(dv,TPL_MAGIC, 3) != 0) return ERR_MAGIC_MISMATCH; /* missing tpl magic prefix */
    if (tpl_needs_endian_swap(dv)) ((tpl_root_data*)(r->data))->flags |= TPL_XENDIAN;
    dv = (void*)((long)dv + 3);
    memcpy(&intlflags,dv,sizeof(char));  /* extract flags */
    dv = (void*)((long)dv + 1);
    memcpy(&intlsz,dv,sizeof(uint32_t));  /* extract internal size */
    if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN) tpl_byteswap(&intlsz, sizeof(uint32_t));
    if (intlsz != bufsz) return ERR_INCONSISTENT_SZ;  /* inconsisent buffer/internal size */
    dv = (void*)((long)dv + sizeof(uint32_t));

    /* dv points to the start of the format string. Look for nul w/in buf sz */
    fmt = (char*)dv;
    while ((long)dv-(long)d < bufsz && !found_nul) {
        if ( (c = *(char*)dv) != '\0') {
            switch (c) {
                case 'i':
                case 'u':
                case 'b':
                case 'd':
                case 'B':
                case 's':
                case 'A':
                case '(':
                case ')':
                    break;
                default:
                    return ERR_FMT_INVALID;  /* invalid char in format string */
            }
            dv = (void*)((long)dv + 1);
        }
        else found_nul = 1;
    }
    if (!found_nul) return ERR_FMT_MISSING_NUL;  /* runaway format string */

    /* compare the map format to the format of this tpl image */
    mapfmt = tpl_fmt(r);
    rc = strcmp(mapfmt,fmt);
    free(mapfmt);
    if (rc != 0) return ERR_FMT_MISMATCH; 

    dv = (void*)((long)dv + 1); /* now dv points to data start */

    rc = tpl_serlen(r,r,dv,&serlen);  /* get computed serlen of data part */
    if (rc == -1) return ERR_INCONSISTENT_SZ2; /* internal inconsitency in tpl image */
    serlen += ((long)dv - (long)d);   /* add back serlen of preamble part */
    if (serlen != bufsz) return ERR_INCONSISTENT_SZ3;  /* buffer/internal sz exceeds serlen */
    return 0;
}

void *tpl_find_data_start(void *d) {
    d = (void*)((long)d + 4); /* skip TPL_MAGIC and flags byte */
    d = (void*)((long)d + 4); /* skip int32 overall len */
    d = (void*)((long)d + strlen(d) + 1);  /* skip fmt + NUL */
    return d;
}

int tpl_needs_endian_swap(void *d) {
    char *c;
    int cpu_is_bigendian;
    c = (char*)d;
    cpu_is_bigendian = tpl_cpu_bigendian();
    return ((c[3] & TPL_FL_BIGENDIAN) == cpu_is_bigendian) ? 0 : 1;
}

TPL_API int tpl_load(tpl_node *r, int mode, ...) {
    va_list ap;
    int rc=0,fd;
    char *filename;
    void *addr;
    int sz;

    va_start(ap,mode);
    if (mode & TPL_FILE) filename = va_arg(ap,char *);
    else if (mode & TPL_MEM) {
        addr = va_arg(ap,void *);
        sz = va_arg(ap,int);
    } else if (mode & TPL_FD) {
        fd = va_arg(ap,int);
    } else {
        tpl_hook.oops("unsupported tpl_load mode %d\n", mode);
        return -1;
    }
    va_end(ap);

    if (r->type != TPL_TYPE_ROOT) {
        tpl_hook.oops("error: tpl_load to non-root node\n");
        return -1;
    }
    if (((tpl_root_data*)(r->data))->flags & (TPL_RDONLY | TPL_WRONLY)) {
        tpl_hook.oops("error: tpl_load into an already-loaded/packed tpl\n");
        return -1;
    }
    if (mode & TPL_FILE) {
        if (tpl_mmap_file(filename, &((tpl_root_data*)(r->data))->mmap) != 0) {
            tpl_hook.oops("tpl_load failed for file %s\n", filename);
            return -1;
        }
        if ( (rc = tpl_sanity(r)) != 0) {
            if (rc == ERR_FMT_MISMATCH) {
                tpl_hook.oops("%s: format signature mismatch\n", filename);
            } else { 
                tpl_hook.oops("%s: not a valid tpl file\n", filename); 
            }
            tpl_unmap_file( &((tpl_root_data*)(r->data))->mmap );
            return -1;
        }
        ((tpl_root_data*)(r->data))->flags = (TPL_FILE | TPL_RDONLY);
    } else if (mode & TPL_MEM) {
        ((tpl_root_data*)(r->data))->mmap.text = addr;
        ((tpl_root_data*)(r->data))->mmap.text_sz = sz;
        if ( (rc = tpl_sanity(r)) != 0) {
            if (rc == ERR_FMT_MISMATCH) {
                tpl_hook.oops("format signature mismatch\n");
            } else { 
                tpl_hook.oops("not a valid tpl file\n"); 
            }
            return -1;
        }
        ((tpl_root_data*)(r->data))->flags = (TPL_MEM | TPL_RDONLY);
        if (mode & TPL_UFREE) ((tpl_root_data*)(r->data))->flags |= TPL_UFREE;
    } else if (mode & TPL_FD) {
        /* if fd read succeeds, resulting mem img is used for load */
        if (tpl_acquire(fd,&addr,&sz) == 0) {
            return tpl_load(r, TPL_MEM|TPL_UFREE, addr, sz);
        } else return -1;
    } else {
        tpl_hook.oops("invalid tpl_load mode %d\n", mode);
        return -1;
    }
    /* this applies to TPL_MEM or TPL_FILE */
    if (tpl_needs_endian_swap(((tpl_root_data*)(r->data))->mmap.text))
        ((tpl_root_data*)(r->data))->flags |= TPL_XENDIAN;
    rc = tpl_unpackA0(r);   /* prepare root A nodes for use */
    return rc;
}

TPL_API int tpl_Alen(tpl_node *r, int i) {
    tpl_node *n;

    n = tpl_find_i(r,i);
    if (n == NULL) {
        tpl_hook.oops("invalid index %d to tpl_unpack\n", i);
        return -1;
    }
    if (n->type != TPL_TYPE_ARY) return -1;
    return ((tpl_atyp*)(n->data))->num;
}

void tpl_free_atyp(tpl_node *n, tpl_atyp *atyp) {
    tpl_backbone *bb,*bbnxt;
    tpl_node *c;
    void *dv;

    bb = atyp->bb;
    while (bb) {
        bbnxt = bb->next;
        dv = bb->data;
        for(c=n->children; c; c=c->next) {
            switch (c->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    dv = (void*)((long)dv + tpl_types[c->type].sz);
                    break;
                case TPL_TYPE_BIN:
                    if ( (*(tpl_bin**)dv)->addr )
                        tpl_hook.mfree( (*(tpl_bin**)dv)->addr ); /* free buf */
                    tpl_hook.mfree(*(tpl_bin**)dv);  /* free tpl_bin */
                    dv = (void*)((long)dv + sizeof(tpl_bin*));
                    break;
                case TPL_TYPE_STR:
                    tpl_hook.mfree(*(char**)dv); /* deep free */
                    dv = (void*)((long)dv + sizeof(char*));
                    break;
                case TPL_TYPE_ARY:
                    tpl_free_atyp(c,*(tpl_atyp**)dv);  /* deep free */
                    dv = (void*)((long)dv + sizeof(void*));
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
        }
        tpl_hook.mfree(bb->data); 
        tpl_hook.mfree(bb);
        bb = bbnxt;
    }
    tpl_hook.mfree(atyp);
}

/* determine (by walking) byte length of serialized r/A node at address dv 
 * returns 0 on success, or -1 if the tpl isn't trustworthy (fails consistency)
 */
int tpl_serlen(tpl_node *r, tpl_node *n, void *dv, off_t *serlen) {
    uint32_t slen;
    int num;
    tpl_node *c;
    off_t len=0, alen, buf_past;

    buf_past = ((long)((tpl_root_data*)(r->data))->mmap.text + 
                      ((tpl_root_data*)(r->data))->mmap.text_sz);

    if (n->type == TPL_TYPE_ROOT) num = 1;
    else if (n->type == TPL_TYPE_ARY) {
        if ((long)dv + sizeof(uint32_t) > buf_past) return -1;
        memcpy(&num,dv,sizeof(uint32_t));
        if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
             tpl_byteswap(&num, sizeof(uint32_t));
        dv = (void*)((long)dv + sizeof(uint32_t));
        len += sizeof(uint32_t);
    } else tpl_hook.fatal("internal error in tpl_serlen\n");

    while (num-- > 0) {
        for(c=n->children; c; c=c->next) {
            switch (c->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    if ((long)dv + tpl_types[c->type].sz > buf_past) return -1;
                    dv = (void*)((long)dv + tpl_types[c->type].sz);
                    len += tpl_types[c->type].sz;
                    break;
                case TPL_TYPE_BIN:
                case TPL_TYPE_STR:
                    len += sizeof(uint32_t);
                    if ((long)dv + sizeof(uint32_t) > buf_past) return -1;
                    memcpy(&slen,dv,sizeof(uint32_t));
                    if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
                        tpl_byteswap(&slen, sizeof(uint32_t));
                    len += slen;
                    dv = (void*)((long)dv + sizeof(uint32_t));
                    if ((long)dv + slen > buf_past) return -1;
                    dv = (void*)((long)dv + slen);
                    break;
                case TPL_TYPE_ARY:
                    if ( tpl_serlen(r,c,dv, &alen) == -1) return -1;
                    dv = (void*)((long)dv + alen);
                    len += alen;
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
        }
    }
    *serlen = len;
    return 0;
}

int tpl_mmap_output_file(char *filename, off_t sz, void **text_out) {
    void *text;
    int fd,perms;

    perms = S_IRUSR|S_IWUSR|S_IWGRP|S_IRGRP|S_IROTH;  /* ug+w o+r */
    fd=open(filename,O_CREAT|O_TRUNC|O_RDWR,perms);
    if ( fd == -1 ) {
        tpl_hook.oops("Couldn't open file %s: %s\n", filename, strerror(errno));
        return -1;
    }

    text = mmap(0, sz, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    if (text == MAP_FAILED) {
        tpl_hook.oops("Failed to mmap %s: %s\n", filename, strerror(errno));
        close(fd);
        return -1;
    }
    if (ftruncate(fd,sz) == -1) {
        tpl_hook.oops("ftruncate failed: %s\n", strerror(errno));
        munmap( text, sz );
        close(fd);
        return -1;
    }
    *text_out = text;
    return fd;
}

int tpl_mmap_file(char *filename, tpl_mmap_rec *mr) {
    struct stat stat_buf;

    if ( (mr->fd = open(filename, O_RDONLY)) == -1 ) {
        tpl_hook.oops("Couldn't open file %s: %s\n", filename, strerror(errno));
        return -1;
    }

    if ( fstat(mr->fd, &stat_buf) == -1) {
        close(mr->fd);
        tpl_hook.oops("Couldn't stat file %s: %s\n", filename, strerror(errno));
        return -1;
    }

    mr->text_sz = stat_buf.st_size;
    mr->text = mmap(0, stat_buf.st_size, PROT_READ, MAP_PRIVATE, mr->fd, 0);
    if (mr->text == MAP_FAILED) {
        close(mr->fd);
        tpl_hook.oops("Failed to mmap %s: %s\n", filename, strerror(errno));
        return -1;
    }

    return 0;
}

TPL_API int tpl_pack(tpl_node *r, int i) {
    return tpl_packN(r, i, 1, 0);
}

TPL_API int tpl_packN(tpl_node *r, int i, int count, int stride) {
    tpl_node *n, *child;
    void *datav=NULL, *child_addrN;
    size_t sz;
    uint32_t slen;
    int j;
    char *str;
    tpl_bin *bin;

    n = tpl_find_i(r,i);
    if (n == NULL) {
        tpl_hook.oops("invalid index %d to tpl_pack\n", i);
        return -1;
    }

    if (((tpl_root_data*)(r->data))->flags & TPL_RDONLY) {
        tpl_hook.oops("can't pack into a pre-loaded tpl (read-only)\n");
        tpl_hook.oops("TODO: implement auto-conversion to a read-write tpl\n");
        return -1;
    }

    ((tpl_root_data*)(r->data))->flags |= TPL_WRONLY;

    for (j=0; j < count; j++) {
        if (n->type == TPL_TYPE_ARY) datav = tpl_extend_backbone(n);
        child = n->children;
        while(child) {
            child_addrN = (void*)((long)(child->addr) + j*stride);
            switch(child->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    memcpy(child->data,child_addrN,tpl_types[child->type].sz);
                    if (datav) datav = tpl_cpv(datav,child->data,tpl_types[child->type].sz);
                    break;
                case TPL_TYPE_BIN:
                    /* copy the buffer to be packed */ 
                    slen = ((tpl_bin*)child_addrN)->sz;
                    if (slen >0) {
                        str = tpl_hook.malloc(slen);
                        if (!str) tpl_hook.fatal("out of memory\n");
                        memcpy(str,((tpl_bin*)child_addrN)->addr,slen);
                    } else str = NULL;
                    /* and make a tpl_bin to point to it */
                    bin = tpl_hook.malloc(sizeof(tpl_bin));
                    if (!bin) tpl_hook.fatal("out of memory\n");
                    bin->addr = str;
                    bin->sz = slen;
                    /* now pack its pointer */
                    memcpy(child->data,&bin,sizeof(tpl_bin*));
                    if (datav) {
                        datav = tpl_cpv(datav, &bin, sizeof(tpl_bin*));
                        *(tpl_bin**)(child->data) = NULL;  
                    }
                    break;
                case TPL_TYPE_STR:
                    /* copy the string to be packed */
                    slen = strlen(*(char**)(child_addrN));
                    str = tpl_hook.malloc(slen+1);
                    if (!str) tpl_hook.fatal("out of memory\n");
                    memcpy(str,*(char**)(child_addrN),slen);
                    str[slen] = '\0';   /* nul terminate */
                    /* now pack its pointer */
                    memcpy(child->data,&str,sizeof(char*));
                    if (datav) {
                        datav = tpl_cpv(datav, &str, sizeof(char*));
                        *(char**)(child->data) = NULL;  
                    }
                    break;
                case TPL_TYPE_ARY:
                    /* copy the child's tpl_atype* and reset it to empty */
                    if (datav) {
                        sz = ((tpl_atyp*)(child->data))->sz;
                        datav = tpl_cpv(datav, &child->data, sizeof(void*));
                        child->data = tpl_hook.malloc(sizeof(tpl_atyp));
                        if (!child->data) tpl_hook.fatal("out of memory\n");
                        ((tpl_atyp*)(child->data))->num = 0;
                        ((tpl_atyp*)(child->data))->sz = sz;
                        ((tpl_atyp*)(child->data))->bb = NULL;
                        ((tpl_atyp*)(child->data))->bbtail = NULL;
                    }
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
            child=child->next;
        }
    }
    return 0;
}

TPL_API int tpl_unpack(tpl_node *r, int i) {
    return tpl_unpackN(r, i, 1, 0);
}

TPL_API int tpl_unpackN(tpl_node *r, int i, int count, int stride) {
    tpl_node *n, *c;
    uint32_t slen;
    int rc=1, j;
    void *child_addrN;
    char *str;
    void *dv;
    off_t A_bytes;

    if (((tpl_root_data*)(r->data))->flags & TPL_WRONLY) {
        tpl_hook.oops("only loaded tpl may be unpacked\n");
        return -1;
    }

    n = tpl_find_i(r,i);
    if (n == NULL) {
        tpl_hook.oops("invalid index %d to tpl_unpack\n", i);
        return -1;
    }

    for(j=0; j < count; j++) {
        /* either root node or an A node */
        if (n->type == TPL_TYPE_ROOT) {
            dv = tpl_find_data_start( ((tpl_root_data*)(n->data))->mmap.text );
        } else if (n->type == TPL_TYPE_ARY) {
            if (((tpl_atyp*)(n->data))->num <= 0) return 0; /* array consumed */
            else rc = ((tpl_atyp*)(n->data))->num--;
            dv = ((tpl_atyp*)(n->data))->cur;
            if (!dv) tpl_hook.fatal("must unpack parent of node before node itself\n");
        }

        for(c=n->children; c; c=c->next) {
            child_addrN = (void*)((long)(c->addr) + j*stride);
            switch (c->type) {
                case TPL_TYPE_BYTE:
                case TPL_TYPE_DOUBLE:
                case TPL_TYPE_INT32:
                case TPL_TYPE_UINT32:
                    memcpy(child_addrN,dv,tpl_types[c->type].sz);
                    if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
                        tpl_byteswap(child_addrN, sizeof(uint32_t));
                    dv = (void*)((long)dv + tpl_types[c->type].sz);
                    break;
                case TPL_TYPE_BIN:
                    memcpy(&slen,dv,sizeof(uint32_t));
                    if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
                        tpl_byteswap(&slen, sizeof(uint32_t));
                    if (slen > 0) {
                        str = (char*)tpl_hook.malloc(slen);
                        if (!str) tpl_hook.fatal("out of memory\n");
                    } else str=NULL;
                    dv = (void*)((long)dv + sizeof(uint32_t));
                    if (slen>0) memcpy(str,dv,slen);
                    memcpy(&(((tpl_bin*)child_addrN)->addr),&str,sizeof(void*));
                    memcpy(&(((tpl_bin*)child_addrN)->sz),&slen,sizeof(uint32_t));
                    dv = (void*)((long)dv + slen);
                    break;
                case TPL_TYPE_STR:
                    memcpy(&slen,dv,sizeof(uint32_t));
                    if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
                        tpl_byteswap(&slen, sizeof(uint32_t));
                    str = (char*)tpl_hook.malloc(slen+1);
                    if (!str) tpl_hook.fatal("out of memory\n");
                    dv = (void*)((long)dv + sizeof(uint32_t));
                    memcpy(str,dv,slen);
                    str[slen] = '\0'; /* nul terminate */
                    memcpy((char**)(child_addrN),&str,sizeof(char*));
                    dv = (void*)((long)dv + slen);
                    break;
                case TPL_TYPE_ARY:
                    if (tpl_serlen(r,c,dv, &A_bytes) == -1) 
                        tpl_hook.fatal("internal error in unpackN\n");
                    memcpy( &((tpl_atyp*)(c->data))->num, dv, sizeof(uint32_t));
                    if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
                        tpl_byteswap(&((tpl_atyp*)(c->data))->num, sizeof(uint32_t));
                    ((tpl_atyp*)(c->data))->cur = (void*)((long)dv+sizeof(uint32_t));
                    dv = (void*)((long)dv + A_bytes);
                    break;
                default:
                    tpl_hook.fatal("unsupported format character\n");
                    break;
            }
        }
        if (n->type == TPL_TYPE_ARY) ((tpl_atyp*)(n->data))->cur = dv; /* next element */
    }
    return rc;
}

/* Specialized function that unpacks only the root's A nodes, after tpl_load  */
int tpl_unpackA0(tpl_node *r) {
    tpl_node *n, *c;
    uint32_t slen;
    int rc=1;
    void *child_addrN;
    char *str;
    void *dv;
    off_t A_bytes;

    n = r;
    dv = tpl_find_data_start( ((tpl_root_data*)(r->data))->mmap.text);

    for(c=n->children; c; c=c->next) {
        child_addrN = c->addr;
        switch (c->type) {
            case TPL_TYPE_BYTE:
            case TPL_TYPE_DOUBLE:
            case TPL_TYPE_INT32:
            case TPL_TYPE_UINT32:
                dv = (void*)((long)dv + tpl_types[c->type].sz);
                break;
            case TPL_TYPE_BIN:
            case TPL_TYPE_STR:
                memcpy(&slen,dv,sizeof(uint32_t));
                if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
                    tpl_byteswap(&slen, sizeof(uint32_t));
                dv = (void*)((long)dv + sizeof(uint32_t));
                dv = (void*)((long)dv + slen);
                break;
            case TPL_TYPE_ARY:
                if ( tpl_serlen(r,c,dv, &A_bytes) == -1) 
                    tpl_hook.fatal("internal error in unpackA0\n");
                memcpy( &((tpl_atyp*)(c->data))->num, dv, sizeof(uint32_t));
                if (((tpl_root_data*)(r->data))->flags & TPL_XENDIAN)
                    tpl_byteswap(&((tpl_atyp*)(c->data))->num, sizeof(uint32_t));
                ((tpl_atyp*)(c->data))->cur = (void*)((long)dv+sizeof(uint32_t));
                dv = (void*)((long)dv + A_bytes);
                break;
            default:
                tpl_hook.fatal("unsupported format character\n");
                break;
        }
    }
    return rc;
}

/* In-place byte order swapping of a word of length "len" bytes */
void tpl_byteswap(void *word, int len) {
    int i;
    char c, *w;
    w = (char*)word;
    for(i=0; i<len/2; i++) {
        c = w[i];
        w[i] = w[len-1-i];
        w[len-1-i] = c;
    }
}

void tpl_fatal(char *fmt, ...) {
    va_list ap;
    char exit_msg[100];

    va_start(ap,fmt);
    vsnprintf(exit_msg, 100, fmt, ap);
    va_end(ap);

    tpl_hook.oops("%s", exit_msg);
    exit(-1);
}

/* acquire a tpl by reading until one full tpl image is obtained.
 * We take care not to read past the end of the tpl.
 * This is intended as a blocking call i.e. for use with a blocking fd.
 * It can be given a non-blocking fd, but the read spins if we have to wait.
 */
TPL_API int tpl_acquire(int fd, void **img, int *sz) {
    char preamble[8];
    int i=0, rc;
    uint32_t tpllen;

    do { 
        rc = read(fd,&preamble[i],8-i);
        i += (rc>0) ? rc : 0;
    } while ((rc==-1 && (errno==EINTR||errno==EAGAIN)) || (rc>0 && i<8));

    if (rc<0) {
        tpl_hook.oops("tpl_acquire failed: %s\n", strerror(errno));
        return -1;
    } else if (rc == 0) {
        tpl_hook.oops("tpl_acquire failed: eof\n");
        return -1;
    } else if (i != 8) {
        tpl_hook.oops("internal error\n");
        return -1;
    }

    if (preamble[0] == 't' && preamble[1] == 'p' && preamble[2] == 'l') {
        memcpy(&tpllen,&preamble[4],4);
        if (tpl_needs_endian_swap(preamble)) tpl_byteswap(&tpllen,4);
    } else {
        tpl_hook.oops("tpl_acquire: non-tpl input\n");
        return -1;
    }

    /* malloc space for remainder of tpl image (overall length tpllen) 
     * and read it in
     */
    if (tpl_hook.fd_tpl_img_maxlen > 0 && 
        tpllen > tpl_hook.fd_tpl_img_maxlen) {
        tpl_hook.oops("tpl exceeds max length %d\n", 
            tpl_hook.fd_tpl_img_maxlen);
        return -2;
    }
    *sz = tpllen;
    if ( (*img = tpl_hook.malloc(tpllen)) == NULL) {
        tpl_hook.fatal("out of memory\n");
    }

    memcpy(*img,preamble,8);  /* copy preamble to output buffer */
    i=8;
    do { 
        rc = read(fd,&((*(char**)img)[i]),tpllen-i);
        i += (rc>0) ? rc : 0;
    } while ((rc==-1 && (errno==EINTR||errno==EAGAIN)) || (rc>0 && i<tpllen));

    if (rc<0) {
        tpl_hook.oops("tpl_acquire failed: %s\n", strerror(errno));
        tpl_hook.mfree(*img);
        return -1;
    } else if (rc == 0) {
        tpl_hook.oops("tpl_acquire failed: eof\n");
        tpl_hook.mfree(*img);
        return -1;
    } else if (i != tpllen) {
        tpl_hook.oops("internal error\n");
        tpl_hook.mfree(*img);
        return -1;
    }

    return 0;
}

/* Used by select()-driven apps which want to gather tpl images piecemeal */
TPL_API int tpl_gather( int fd, tpl_gather_t **gs, tpl_gather_cb *cb, void *data) { 
    char buf[TPL_GATHER_BUFLEN], *img, *tpl;
    int rc, catlen, keep_looping;
    uint32_t tpllen;

    while (1) {
        rc = read(fd,buf,TPL_GATHER_BUFLEN);
        if (rc == -1) {
            if (errno == EINTR) continue;  /* got signal during read, ignore */
            if (errno == EAGAIN) return 1; /* nothing to read right now */
            else {
                tpl_hook.oops("tpl_gather failed: %s\n", strerror(errno));
                if (*gs) {
                    tpl_hook.mfree((*gs)->img);
                    tpl_hook.mfree(*gs);
                    *gs = NULL;
                }
                return -1;                 /* error, caller should close fd  */
            }
        } else if (rc == 0) {
            if (*gs) {
                tpl_hook.oops("tpl_gather: partial tpl image precedes EOF\n");
                tpl_hook.mfree((*gs)->img);
                tpl_hook.mfree(*gs);
                *gs = NULL;
            }
            return 0;                      /* EOF, caller should close fd */
        } else {
            /* concatenate any partial tpl from last read with new buffer */
            if (*gs) {
                catlen = (*gs)->len + rc;
                if (tpl_hook.fd_tpl_img_maxlen > 0 && 
                    catlen > tpl_hook.fd_tpl_img_maxlen) {
                    tpl_hook.mfree( (*gs)->img );
                    tpl_hook.mfree( (*gs) );
                    *gs = NULL;
                    tpl_hook.oops("tpl exceeds max length %d\n", 
                        tpl_hook.fd_tpl_img_maxlen);
                    return -2;              /* error, caller should close fd */
                }
                if ( (img = tpl_hook.realloc((*gs)->img, catlen)) == NULL) {
                    tpl_hook.fatal("out of memory\n");
                }
                memcpy(img + (*gs)->len, buf, rc);
                tpl_hook.mfree(*gs);
                *gs = NULL;
            } else {
                img = buf;
                catlen = rc;
            }
            /* isolate any full tpl(s) in img and invoke cb for each */
            tpl = img;
            keep_looping = (tpl+8 < img+catlen) ? 1 : 0;
            while (keep_looping) {
                if (strncmp("tpl", tpl, 3) != 0) {
                    tpl_hook.oops("tpl prefix invalid\n");
                    if (img != buf) tpl_hook.mfree(img);
                    tpl_hook.mfree(*gs);
                    *gs = NULL;
                    return -3; /* error, caller should close fd */
                }
                memcpy(&tpllen,&tpl[4],4);
                if (tpl_needs_endian_swap(tpl)) tpl_byteswap(&tpllen,4);
                if (tpl+tpllen <= img+catlen) {
                    (cb)(tpl,tpllen,data);  /* invoke cb for tpl image */
                    tpl += tpllen;          /* point to next tpl image */
                    keep_looping = (tpl+8 < img+catlen) ? 1 : 0;
                } else keep_looping=0;
            } 
            /* store any leftover, partial tpl fragment for next read */
            if (tpl == img && img != buf) {  
                /* consumed nothing from img!=buf */
                if ( (*gs = tpl_hook.malloc(sizeof(tpl_gather_t))) == NULL ) {
                    tpl_hook.fatal("out of memory\n");
                }
                (*gs)->img = tpl;
                (*gs)->len = catlen;
            } else if (tpl < img+catlen) {  
                /* consumed 1+ tpl(s) from img!=buf or 0 from img==buf */
                if ( (*gs = tpl_hook.malloc(sizeof(tpl_gather_t))) == NULL ) {
                    tpl_hook.fatal("out of memory\n");
                }
                if ( ((*gs)->img = tpl_hook.malloc(img+catlen - tpl)) == NULL ) {
                    tpl_hook.fatal("out of memory\n");
                }
                (*gs)->len = img+catlen - tpl;
                memcpy( (*gs)->img, tpl, img+catlen - tpl);
                /* free partially consumed concat buffer if used */
                if (img != buf) tpl_hook.mfree(img); 
            } else {                        /* tpl(s) fully consumed */
                /* free consumed concat buffer if used */
                if (img != buf) tpl_hook.mfree(img); 
            }
        }
    } 
}

